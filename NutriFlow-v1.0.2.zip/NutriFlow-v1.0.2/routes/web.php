<?php

use App\Http\Controllers\Auth\LoginController;
use App\Http\Controllers\FeedingScheduleController;
use App\Http\Controllers\FoodController;
use App\Http\Controllers\MealController;
use App\Http\Controllers\NutritionAideController;
use App\Http\Controllers\NutritionPlanController;
use App\Http\Controllers\ReportController;
use App\Http\Controllers\SettingsController;
use App\Http\Controllers\StudentController;
use App\Http\Controllers\StudentImportController;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Route;

// Auth routes
Route::get('/login', [LoginController::class, 'showLoginForm'])->name('login');
Route::post('/login', [LoginController::class, 'login'])->name('login.submit');
Route::post('/logout', [LoginController::class, 'logout'])->name('logout');

// Default redirect
Route::get('/', function () {
    return redirect()->route('login');
});

Route::middleware(['auth'])->group(function () {
    Route::get('/dashboard', [NutritionAideController::class, 'dashboard'])->name('dashboard');
    Route::get('/dashboard/feeding-schedule', [NutritionAideController::class, 'feedingSchedule'])->name('dashboard.feeding-schedule');

    Route::get('/students', [StudentController::class, 'index'])->name('students.index');
    Route::get('/students/{student}', [StudentController::class, 'show'])->whereNumber('student')->name('students.show');
    Route::post('/students/{student}/measurements', [StudentController::class, 'storeMeasurement'])->whereNumber('student')->name('students.measurements.store');
    Route::post('/students/{student}/nutrition-assessment', [NutritionPlanController::class, 'assess'])
        ->whereNumber('student')
        ->middleware('throttle:10,1')
        ->name('students.nutrition-assessment');

    Route::get('/meals', [MealController::class, 'index'])->name('meals.index');
    Route::get('/meals/batch', [MealController::class, 'batch'])->name('meals.batch');
    Route::post('/meals/batch', [MealController::class, 'batchStore'])->name('meals.batch.store');

    Route::get('/feeding-schedules', [FeedingScheduleController::class, 'index'])->name('feeding-schedules.index');
    Route::post('/feeding-schedules/recommendations', [FeedingScheduleController::class, 'recommendations'])
        ->middleware('throttle:5,1')
        ->name('feeding-schedules.recommendations');
    Route::post('/feeding-schedules', [FeedingScheduleController::class, 'store'])->name('feeding-schedules.store');
    Route::patch('/feeding-schedules/{feedingSchedule}', [FeedingScheduleController::class, 'update'])->name('feeding-schedules.update');

    Route::get('/menu-items', [FoodController::class, 'index'])->name('menu-items.index');
    Route::get('/menu-items/{food}', [FoodController::class, 'show'])->whereNumber('food')->name('menu-items.show');

    Route::get('/reports', [ReportController::class, 'index'])->name('reports.index');
    Route::get('/settings', [SettingsController::class, 'index'])->name('settings.index');
    Route::post('/settings/theme', [SettingsController::class, 'updateTheme'])->name('settings.theme');
    Route::post('/settings/password', [SettingsController::class, 'updatePassword'])->name('settings.password');

    Route::middleware('role:school_admin')->group(function () {
        Route::get('/students/create', [StudentController::class, 'create'])->name('students.create');
        Route::post('/students', [StudentController::class, 'store'])->name('students.store');
        Route::post('/students/sections', [StudentController::class, 'storeSection'])->name('students.sections.store');
        Route::get('/students/{student}/edit', [StudentController::class, 'edit'])->name('students.edit');
        Route::patch('/students/{student}', [StudentController::class, 'update'])->name('students.update');
        Route::delete('/students/{student}', [StudentController::class, 'destroy'])->name('students.destroy');

        Route::get('/student-import', [StudentImportController::class, 'index'])->name('student-import.index');
        Route::get('/student-import/template', [StudentImportController::class, 'template'])->name('student-import.template');
        Route::post('/student-import', [StudentImportController::class, 'import'])->name('student-import.import');

        Route::delete('/meals/{meal}', [MealController::class, 'destroy'])->name('meals.destroy');
        Route::delete('/feeding-schedules/{feedingSchedule}', [FeedingScheduleController::class, 'destroy'])->name('feeding-schedules.destroy');

        Route::get('/menu-items/create', [FoodController::class, 'create'])->name('menu-items.create');
        Route::post('/menu-items', [FoodController::class, 'store'])->name('menu-items.store');
        Route::get('/menu-items/{food}/edit', [FoodController::class, 'edit'])->name('menu-items.edit');
        Route::patch('/menu-items/{food}', [FoodController::class, 'update'])->name('menu-items.update');
        Route::delete('/menu-items/{food}', [FoodController::class, 'destroy'])->name('menu-items.destroy');
        Route::post('/menu-items/upload-csv', [FoodController::class, 'uploadCsv'])->name('menu-items.uploadCsv');

        Route::get('/reports/export/csv', [ReportController::class, 'exportCsv'])->name('reports.export.csv');
        Route::get('/reports/export/pdf', [ReportController::class, 'exportPdf'])->name('reports.export.pdf');
    });
});
